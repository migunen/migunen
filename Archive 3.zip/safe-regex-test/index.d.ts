declare function regexTester(regex: RegExp): (string: string) => boolean;

export = regexTester;