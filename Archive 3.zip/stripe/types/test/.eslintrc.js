module.exports = {
  extends: '../.eslintrc.js',
  rules: {
    '@typescript-eslint/ban-ts-comment': 0,
  },
};
