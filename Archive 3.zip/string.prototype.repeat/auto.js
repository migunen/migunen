/*! https://mths.be/repeat v1.0.0 by @mathias */

require('./shim')();
