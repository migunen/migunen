# SDP parsing and utlities
originally for generating SDP from ORTC and vice versa -- see https://github.com/fippo/adapter/tree/shim-ortc

But it turned out to be useful for manipulating SDP outside the context of Microsofts Edge browser.
