export { canUseDOM, areOptionsEqual, sortAndMapPluginToOptions, arePluginsEqual } from './components/utils.js';
