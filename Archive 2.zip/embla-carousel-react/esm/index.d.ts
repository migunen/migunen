export { UseEmblaCarouselType, EmblaViewportRefType } from './components/useEmblaCarousel.js';
export { default } from './components/useEmblaCarousel.js';
