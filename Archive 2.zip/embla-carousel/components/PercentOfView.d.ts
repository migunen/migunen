export type PercentOfViewType = {
    measure: (n: number) => number;
};
export declare function PercentOfView(viewSize: number): PercentOfViewType;
